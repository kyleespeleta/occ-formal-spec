#!/bin/bash
# Reproduce derived outputs and record run details.
set -euo pipefail

# Capture UTC timestamp
timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
# Record Python version
python_version=$(python3 --version | tr -d '\n')

# Capture the full pip freeze output and compute its SHA‑256
pip_freeze_file="submission/pip_freeze.txt"
python3 -m pip freeze > "$pip_freeze_file"
pip_freeze=$(sha256sum "$pip_freeze_file" | awk '{print $1}')

# Define input and output locations
input_file="raw/bpi_incidents_ledger.csv"
output_dir="submission/derived"
mkdir -p "$output_dir"

# Compute input file hash
input_hash=$(sha256sum "$input_file" | awk '{print $1}')

# Command used to generate the derived outputs
cmd="python3 occ_harness.py --ledger $input_file --horizon_days 30 --window_days 90 --output_dir $output_dir"

# Remove any existing outputs to ensure reproducibility
rm -f "$output_dir"/timeseries.csv "$output_dir"/diagnostics.json || true

# Execute the harness
eval "$cmd"

# Compute output hashes
ts_hash=$(sha256sum "$output_dir/timeseries.csv" | awk '{print $1}')
diag_hash=$(sha256sum "$output_dir/diagnostics.json" | awk '{print $1}')

# Write the run log
cat <<EOL > submission/RUNLOG.txt
timestamp: $timestamp
git_commit: no git
python_version: $python_version
pip_freeze_sha256: $pip_freeze
input_hashes:
  bpi_incidents_ledger.csv: $input_hash
command: $cmd
output_hashes:
  timeseries.csv: $ts_hash
  diagnostics.json: $diag_hash
EOL