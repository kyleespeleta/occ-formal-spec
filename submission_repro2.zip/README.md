# Reproducibility Guide

## How to reproduce

1. Ensure Python 3.11.2 is available.
2. Create a clean virtual environment and install dependencies from `requirements.lock` (or from `submission/pip_freeze.txt` if that is what is provided).
3. Confirm `raw/bpi_incidents_ledger.csv` is present.
4. Run `make reproduce` from the project root (or execute `./run.sh`). This regenerates `submission/derived/timeseries.csv` and `submission/derived/diagnostics.json`.
5. Verify reproducibility by comparing SHA‑256 hashes of regenerated outputs to `submission/CHECKSUMS.sha256`.
6. Inspect `submission/RUNLOG.txt` for timestamp, environment, exact command executed, and input/output hashes.

## Expected hashes

- `timeseries.csv`: `f9f81f69c9679b8bf23ab5569bc82fe15a8232976ae18fe2c9afeafff6830f3b`
- `diagnostics.json`: `4177a4eacb0edfdc741a5cc1cd3469788158b309bb5355ad3efe830074c198d6`

## Observability at Tier‑1

Tier‑1 analysis measures daily exogenous arrivals, completion attempts, durable completions, bounce‑backs and backlog as specified by the Operator Closure Constraint protocol.  It assesses whether attempted completions decompose into durable completions and bounce‑backs but does not attempt to infer causes or drivers.  Any information not contained in the ledger (for example, external quality standards or process drivers) is unobservable and excluded from Tier‑1 analyses.